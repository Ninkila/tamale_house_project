from pathlib import Path

import pandas as pd
import streamlit as st


@st.cache_data
def load_house():
    csv_path = Path(__file__).resolve().parents[1] / "data" / "tamale_house_rentals.csv"
    return pd.read_csv(csv_path)


def search_houses(budget, location, bedroom, water, bathroom):
    # Validate first
    if budget < 0:
        raise ValueError("Budget cannot be negative")
    if bedroom < 0:
        raise ValueError("Bedrooms cannot be negative")
    if bathroom < 0:
        raise ValueError("Bathrooms cannot be negative")

    houses = load_house().copy()
    for col in ("monthly_rent_ghs", "rooms", "bathrooms"):
        houses[col] = pd.to_numeric(houses[col], errors="coerce")

    # Within budget; at least the requested rooms/bathrooms
    mask = (
        houses["monthly_rent_ghs"].le(budget)
        & houses["rooms"].ge(bedroom)
        & houses["bathrooms"].ge(bathroom)
    )

    if location and str(location).strip():
        text = str(location).strip().lower()
        mask &= houses["neighborhood"].fillna("").astype(str).str.lower().str.contains(text, regex=False)

    if water and str(water).strip().lower() != "any":
        text = str(water).strip().lower()
        mask &= houses["water"].fillna("").astype(str).str.lower().eq(text)

    return houses.loc[mask].sort_values(by="monthly_rent_ghs", ascending=True)


def find_houses(budget, location, bedroom, water, bathroom):
    return search_houses(budget, location, bedroom, water, bathroom)
